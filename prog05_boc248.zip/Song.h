// Brent Ciftja
// EE312 boc248
// 16015

#ifndef LAB5_SONG_H
#define LAB5_SONG_H

//#endif //LAB5_SONG_H

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class Song{
private:
    string artist;
    string title;
    int memsize;

public:
    Song();
    Song(string, string, int);

    //Each of these 3 string functions get artist, title, memsize
    //of each new song
    string got_artist() const;

    string got_title() const;

    int got_memsize() const;


    //Each of these 3 void functions sets artist, title, memsize
    // of an "overwrittern"/swapped new song
    void set_artist(string art);

    void set_title(string tit);

    void set_memsize(int memsi);

// &rhs= Address of object which reference/ptr is pointing to
    bool operator >(Song const &rhs);
    bool operator ==(Song const &rhs);
    bool operator <(Song const &rhs);

};

#endif //LAB5_SONG_H
