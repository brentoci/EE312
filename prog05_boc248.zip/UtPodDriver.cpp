// Brent Ciftja
// boc248 EE312
// 16015

/* utPod_driver.cpp
Demo Driver for the UtPod.

Roger Priebe
EE 312 10/16/18

This is a basic driver for the UtPod.

You will want to do more complete testing.

*/
#include <cstdlib>
#include <iostream>
#include "Song.h"
#include "UtPod.h"

using namespace std;

int main(int argc, char *argv[])
{
    UtPod t;

    //TEST 1= ADD/DELETE songs in list            ////////
    //   result=0 and add_result=0 means success  ////////
    //////////////////////////////////////////////////////
    cout<< " TEST1\n";

    Song s1("Louane", "Avenir", 4);
    int result = t.addSong(s1);
    cout << "result = " << result << endl;


    t.showSongList();

    Song s2("Louane", "Jeune", 5);
    result = t.addSong(s2);
    cout << "result = " << result << endl;

    t.showSongList();

    Song s3("Lyng", "Play My Drum", 6);
    result = t.addSong(s3);
    cout << "result = " << result << endl;

    Song s4("Beatles", "Hey Jude4", 7);
    result = t.addSong(s4);
    cout << "result = " << result << endl;

    Song s5("Psy", "Gangnam Style", 241);
    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    Song s6("Psy", "Gangnam Style", 249);
    result = t.addSong(s6);
    cout << "add result = " << result << endl;

    t.showSongList();
    cout << " \n";
    cout << " \n";

    //TEST 2= ADD/DELETE songs in linked list //////////
    //    and calculates memory remaining.    //////////
    //        delete_result=0 means SUCCESS   //////////
    ////////////////////////////////////////////////////
    cout<< "TEST2\n";
    result= t.removeSong(s6);

    result = t.removeSong(s2);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s3);
    cout << "delete result = " << result << endl;

    t.showSongList();

    result = t.removeSong(s1);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s5);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s4);
    cout << "delete result = " << result << endl;


    t.showSongList();

    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    t.showSongList();
    cout<<  "memory initial= " <<t.getTotalMemory()<< endl;
    cout << "memory now = " << t.getRemainingMemory() << endl;
    cout << " \n";
    cout << " \n";

    // TEST 3= Sorts songs based by artist/////////
    ///////////////////////////////////////////////
    //The code continues.....
    cout<< "TEST3\n";

    result = t.addSong(s3);
    cout << "result = " << result << endl;

    result = t.addSong(s4);
    cout << "result = " << result << endl;

    result = t.addSong(s1);
    cout << "result = " << result << endl;

    t.showSongList();

    //Proves that this sorts
    t.sortSongList();
    cout<< " \n";
    //cout<< " \n";
    t.showSongList();

    //TEST 4= Sorts songs based on artist ////
    // and then title if artist==a rtist  ////
    //////////////////////////////////////////

    result = t.removeSong(s5);
    cout << "delete result = " << result << endl;

    result = t.addSong(s2);  //Adding Jeune
    cout << "result = " << result << endl;

    cout<< " \n";
    cout<< " \n";
    cout<<" TEST4\n";
    //Proves that this sorts with same named artist
    //t.showSongList();   //MORE PROOF: Uncomment this
    t.sortSongList();
    t.showSongList();

//    //TEST 5= Shuffles songs //////////////////
//    ///////////////////////////////////////////
//
//    //Proves that this shuffles (albeit it may segfault)
//    t.shuffle();
//    cout<< " \n";
//    cout<< " \n";
//    cout<< " TEST5\n";
//    t.showSongList();
//    //cout<< "hi";

    //TEST 5= Checks Overflowed Condition///////
    // if overflowed, add_result= -1     ///////
    ////////////////////////////////////////////

    cout<< " \n";
    cout<< " \n";
    cout<< " TEST5\n";

    //Checks the Overflowed condition
    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    t.showSongList();

    //TEST 6= Checks Underflowed condition//////
    // if underflowed,  delete_result= -2 //////
    ////////////////////////////////////////////

    cout<< " \n";
    cout<< " \n";
    cout<< " TEST6\n";

    //Checks the Underflowed condition
    result = t.removeSong(s5);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s5);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s4);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s1);
    cout << "delete result = " << result << endl;

    result = t.removeSong(s2);
    cout << "delete result = " << result << endl;

    t.showSongList();  //Lyng is left
    result = t.removeSong(s3);
    cout << "delete result = " << result << endl;

    t.showSongList();
    result = t.removeSong(s5); //None left
    cout << "delete result = " << result << endl;


    //TEST 7= Sorts based by artist        //////
    //        then title then smaller SIZE //////
    /////////////////////////////////////////////

    cout<< " \n";
    cout<< " \n";
    cout<< " TEST7\n";
    //Proves that this sorts with same artist/title
    result = t.addSong(s5);
    cout << "add result = " << result << endl;

    result = t.addSong(s3);
    cout << "add result = " << result << endl;

    result = t.addSong(s6);
    cout << "add result = " << result << endl;


    t.showSongList();
    cout << "memory = " << t.getRemainingMemory() << endl;

    t.sortSongList();
    cout<< " \n";
    t.showSongList();



////TEST9
//    cout<<("\n TEST9");
//    t.clearMemory();
//    t.showSongList();

    return 0; //Made to prevent segfault
}
