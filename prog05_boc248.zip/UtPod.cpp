//
// Created by brent.o.ci on 10/18/2019.
//

#include "UtPod.h"
#include <iostream>
#include <cstdlib>
#include <string>

#include <time.h>

using namespace std;

//Creates NULL ptr at songs as HEAD
// and MAX ptr at memSize as TAIL
UtPod::UtPod() {
    songs=NULL;
    memSize=MAX_MEMORY;  //memSize= 512 MB or ???
}

// Checks if size is out of bounds
//if so set to MAX
UtPod::UtPod(int size) {
    songs=NULL;
    if((size> MAX_MEMORY) || (size<=0))
        {//memSize=MAX_MEMORY;
           size=MAX_MEMORY; }
}

int UtPod::addSong(Song const &s) {
if(s.got_memsize()<= getRemainingMemory()){
    SongNode *new_song= new SongNode;
    new_song->s=s;
    //Put s value into SongNode pting to s

    //Now add NULL value to "next" pt of StackNode
    // by changing the HEAD called 'songs'
    new_song->next= songs;
    songs= new_song;
    //songs= new_song;
    //showSongList();
    return SUCCESS;
}
    else{
        return (-1);   //Return NO_MEMORY
    }
}

int UtPod::removeSong(Song const &s) {
    SongNode *headon= songs;   //This leads
    SongNode *prior= songs;    //This follows one behind
    //SongNode *temp;

    int i=0;
    while(headon != NULL)
    {

        if((headon->s==s) && i==0)
        {
            songs= songs->next;
            delete(headon);
            return SUCCESS;
        }

        if(headon->s==s)
        {
           // temp->next= headon->next;
            prior->next=headon->next; //redundant
            delete(headon);
            return SUCCESS;
        }
        //else { return NOT_FOUND;}  //new extension

        //temp= headon;
        prior= headon;
        headon=headon->next;
        i++;
    }

    if(i==0)
    {
        return NOT_FOUND;
    }
   // return NOT_FOUND; //because we're out search it is lost
}

void UtPod::shuffle() {
    SongNode *headon= songs; //This leads
    //SongNode *prior= songs;  //This follows

    SongNode *counter=songs;
    //Ptr to HEAD to see how many songs we've
    int i=0;
    SongNode help;  //Carries value of type SongNode

    headon=headon->next;
    while(counter != NULL )
    {
        i++;
        counter=counter->next;
    }

    int meh= rand();
    //int shuffle= rand()%i;
    int shuffle=meh%i;

    counter=headon;
    int u,j;
    //for(u=0; u<meh; u++)
    {
        for (j=0; j< shuffle; j++) {
            counter= counter->next;
            //swap();
        }

        //Switching values of one SongNode
        // ptr to the other
        help.s=headon->s;
        headon->s= counter->s; //Check this
        counter->s=help.s;

    }



}

void UtPod::showSongList() {
    SongNode *list= songs;
    while(list != NULL)
    {
        cout<< list->s.got_artist()<< ", ";
        cout<< list->s.got_title()<< ", ";
        cout<< list->s.got_memsize() << " MB ";
        cout<<" \n";
        list=list->next;
    }
}

void UtPod::sortSongList() {
    SongNode *heady= songs;
    SongNode helper;     //Variable that holds type SongNode

    SongNode *temp1=songs;
    SongNode *temp2=songs->next;
    //SongNode helper2;

    while(heady!= NULL)
    {
        while(temp2 != NULL){
            if(temp1->s.got_artist()> temp2->s.got_artist())
            {
                helper.s=temp1->s;
                temp1->s=temp2->s;
                temp2->s= helper.s;
            }

            else if(temp1->s.got_artist() == temp2->s.got_artist())
                {if(temp1->s.got_title()>temp2->s.got_title())
                    {
                        helper.s=temp1->s;
                        temp1->s=temp2->s;
                        temp2->s= helper.s;
                    }
                }

//            //Problem: it skips this, else if
//            else {if (temp1->s.got_artist() == temp2->s.got_artist())
//            {if(temp1->s.got_title() == temp2->s.got_title()){
//                if(temp1->s.got_memsize() > temp2->s.got_memsize() )
//                {
//                    helper.s=temp1->s;
//                    temp1->s=temp2->s;
//                    temp2->s= helper.s;
//                }
//             }
//            } }

            int hi=0;
            if (temp1->s.got_artist() == temp2->s.got_artist())
                {if(temp1->s.got_title() == temp2->s.got_title()){
                        if(temp1->s.got_memsize() > temp2->s.got_memsize() )
                        {
                            helper.s=temp1->s;
                            temp1->s=temp2->s;
                            temp2->s= helper.s;
                        }
                    }
                } //}

            temp2= temp2->next;  //Problem maybe here?
        }

        heady= heady->next;
        temp1= heady;
    //    temp2= heady->next;
        temp2= temp1;

    }

}

void UtPod::clearMemory() {
    SongNode *ptr1= songs;   //*ptr1= HEAD= begin of list
    SongNode *ptr2= ptr1;    //*ptr2=*ptr1 (cloned it)

    //Continue until ptr1 reaches end of list
    while( ptr1 != NULL)
    {
        ptr2= ptr1->next;
        delete (ptr1);   //Delete previous ptr1
        ptr1= ptr2;      //ptr1= ptr1-> next
    }

}

//int UtPod::getTotalMemory(){
//
//}

int UtPod::getRemainingMemory() {
    int totsum=0;
    SongNode *value= songs; //*value= HEAD= begin of list

    //Continue until value reaches end of list
    while(value != NULL )
    {
        totsum= totsum+ value->s.got_memsize();
        value= value->next;
    }

    totsum= memSize-totsum;
    return totsum;

}

UtPod::~UtPod() {
    clearMemory();
}



