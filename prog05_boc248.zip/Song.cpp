// Brent Ciftja
// EE312 boc248
// 16015

#include "Song.h"

using namespace std;

Song::Song() {
    artist="";
    title="";
    memsize=0;
}

Song::Song(string artist, string title, int memsize ) {
    this->artist=artist;
    this->title=title;
    this->memsize=memsize;
}

string Song::got_artist() const {
    return artist;
}

string Song::got_title() const {
    return title;
}

int Song::got_memsize() const {
    return memsize;
}



void Song::set_artist(string art) {
    artist=art;
}

void Song::set_title(string tit) {
    title=tit;
}

void Song::set_memsize(int memsi) {
    memsize=memsi;
}

// bool Song::operator<(Song const &rhs) {
//    if((artist< rhs.artist) || (title< rhs.title) ||(memsize< rhs.memsize))
//    { return true;}
//    else {return false;}
//};

 bool Song::operator==(Song const &rhs) {
    if((artist== rhs.artist) && (title==rhs.title) && (memsize==rhs.memsize))
    { return true;}
    else {return false;}
 };

 bool Song::operator>(Song const &rhs) {
     if((artist> rhs.artist) || (title> rhs.title) ||(memsize> rhs.memsize))
     { return true;}
     else {return false;}
 };


