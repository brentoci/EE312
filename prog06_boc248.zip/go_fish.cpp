//
// Created by brent.o.ci on 11/2/2019.
// WILL USE THIS TEMPORARILY

// FILE: card_demo.cpp
// This is a small demonstration program showing how the Card and Deck classes are used.
#include <iostream>    // Provides cout and cin
#include <cstdlib>     // Provides EXIT_SUCCESS
#include <vector>
#include <fstream>
#include "card.h"
#include "player.h"
#include "deck.h"

using namespace std;


// PROTOTYPES for functions used by this demonstration program:
void dealHand(Deck &d, Player &p, int numCards);




int main( )
{
    //1 ofstream file;
    //  file.open("Gofish_results.txt");
    //  file<<
    //  file.close();
    ofstream file("Gofish_results.txt");
    //2 freopen("Gofish_results.txt","w",stdout);
    //  cout<<
    //  fclose (stdout);
    //3 ofstream fout("Gofish_results.txt");
    //  fout<<
    //  fout.close()

    int numCards = 7;
    Player p1("Joe");
    Player p2("Jane");

    Deck d;  //create a deck of cards
    d.shuffle();

    dealHand(d, p1, numCards);
    dealHand(d, p2, numCards);

    cout << p1.getName() <<" has : " << p1.showHand() << endl;
    cout << p2.getName() <<" has : " << p2.showHand() << endl;

    cout << p1.getName()<<" has: " << p1.getBookSize() <<" books " <<endl;
    cout << p1.getName()<<" has: " << p1.getHandSize() <<" cards " <<endl;
    cout << d.size() <<" cards remaining " <<endl;

    //Sending value to file works
    //file << p1.getName()<<" has: " << p1.getBookSize()<< " books"<<endl ;

    file << p1.getName() <<" has : " << p1.showHand() << endl;
    file << p2.getName() <<" has : " << p2.showHand() << endl;

    file << p1.getName()<<" has: " << p1.getBookSize() <<" books " <<endl;
    file << p1.getName()<<" has: " << p1.getHandSize() <<" cards " <<endl;
    file << d.size() <<" cards remaining " <<endl;

    Card card1;
    Card card2;

     cout<< card1.getRank()<<endl;
    cout<< card2.getRank()<<endl;
    while(p1.checkHandForBook(card1,card2))
        {
            cout<<"Card1 Before "<< card1.getRank()<<endl;
            cout<<"Card2 Before "<< card2.getRank()<<endl;

            p1.bookCards(card1,card2);
            card1= p1.removeCardFromHand(card1);
            card2= p1.removeCardFromHand(card2);
            //p1.bookCards(card1,card2);
        }
    //cout << card1.toString()<< endl;
    cout <<card1.rankString(card1.getRank())<<endl;
    cout<<"Card1 After "<< card1.getRank()<<endl;
    cout<<"Card2 After "<< card2.getRank()<<endl;
    cout<<p1.showHand()<<endl;
    cout<<p1.showBooks()<<endl;
    cout<<"P1 has "<<p1.getBookSize()<<"Books"<<endl;

    cout<<"P1 has "<<p1.getHandSize()<<"Cards\n"<<endl;


    cout<<"For P2"<<endl;
    while(p2.checkHandForBook(card1,card2))
    {
        cout<<"Card1 Before "<< card1.getRank()<<endl;
        cout<<"Card2 Before "<< card2.getRank()<<endl;

        p2.bookCards(card1,card2);
        card1= p2.removeCardFromHand(card1);
        card2= p2.removeCardFromHand(card2);
    }
    //cout << card1.toString()<< endl;
    cout <<card1.rankString(card1.getRank())<<endl;
    cout<<"Card1 After "<< card1.getRank()<<endl;
    cout<<"Card2 After "<< card2.getRank()<<endl;
    cout<<p2.showHand()<<endl;
    cout<<p2.showBooks()<<endl;
    cout<<"P2 has "<<p2.getBookSize()<<"Books"<<endl;

    cout<<"P2 has "<<p2.getHandSize()<<"Cards"<<endl;

    //while(p1.getBookSize()+ p2.getBookSize()<26)
    //while(d.size() !=0)
    while((d.size()!=0 && p1.getBookSize()<14) || (d.size()!=0 && p2.getBookSize()<14))
    {
        //p1 turn
        int repli=1;
        while(repli==1) {
            cout << p1.getName() << endl;
            Card asked = p1.chooseCardFromHand();
            Card got_card;
            file <<"Joe: Do you have "<< asked.rankString(asked.getRank()) << " ?"<< endl;
            //Must declare explicitly NOT implicitly

            //Checks if other player has card
            cout << p2.cardInHand(asked) << endl; //True or False (1 or 0)
            repli = p2.cardInHand(asked);
            if(repli==1){    //Take card from other and Book
                file<< "Jane: Yes I do have "<< asked.rankString(asked.getRank()) <<"!\n"<<endl;
                got_card= p2.removeCardFromHand(asked);
                file<<got_card.rankString(got_card.getRank())<<endl;

                p1.bookCards(asked, got_card);
                p1.removeCardFromHand(asked);
                file<<p1.getName()<<" books"<< asked.rankString(asked.getRank())<<endl;
            }else{
                file<<p2.getName()<<": Go Fish!\n" << endl;
                if(d.size()>0)
                {p1.addCard(d.dealCard());} //Take card from deck
                cout<< d.size()<<"cards remaining"<<endl;
            }
        }

        //p2 turn
        repli=1;
        while(repli==1) {
            cout << p2.getName() << endl;
            Card asked = p2.chooseCardFromHand();
            Card got_card;
            file <<"Jane: Do you have "<< asked.rankString(asked.getRank()) << " ?"<< endl;
            //Must declare explicitly NOT implicitly

            //Checks if other player has card
            cout << p1.cardInHand(asked) << endl; //True or False (1 or 0)
            repli = p1.cardInHand(asked);
            if(repli==1){    //Take card from other and Book
                file<< "Joe: Yes I do have "<< asked.rankString(asked.getRank()) <<"!\n"<<endl;
                got_card= p1.removeCardFromHand(asked);
                file<<got_card.rankString(got_card.getRank())<<endl;

                p2.bookCards(asked, got_card);
                p2.removeCardFromHand(asked);
                file<<p2.getName()<<" books"<< asked.rankString(asked.getRank())<<endl;
            }else{
                file<<p1.getName()<<": Go Fish!\n" << endl;
                file<<"Remaining"<<d.size()<<endl;
                if(d.size()>0)
                { p2.addCard(d.dealCard());} //Take card from deck
                cout<< d.size()<<"cards remaining"<<endl;
            }
        }

    }

        file<<"P1 has books of" <<p1.getBookSize()<<endl;
        file<<"P2 has books of" <<p2.getBookSize()<<endl;
        file<<"Cards left"<<d.size()<<endl;
        file<<p1.getName()<<"HAS "<<p1.showHand()<<endl;
        file<<p2.getName()<<"HAS "<<p2.showHand()<<endl;
        //file<<"P1's books are "<<p1.showBooks()<<endl;

        if(p1.getBookSize() > p2.getBookSize())
            {file<<p1.getName()<<" wins by "<<p1.getBookSize()<<"books"<<endl;}

        if(p2.getBookSize() >p1.getBookSize())
            {file<<p2.getName()<<" wins by "<<p2.getBookSize()<<"books"<<endl;}

        if(p1.getBookSize()==p2.getBookSize())
            {file<<"Game is tied by "<< p1.getBookSize()<< endl;}

            file.close();


    return EXIT_SUCCESS;
}



void dealHand(Deck &d, Player &p, int numCards)
{
    for (int i=0; i < numCards; i++)
        p.addCard(d.dealCard());
}









