//
// Created by brent.o.ci on 11/2/2019.
//

#include "deck.h"
#include <iostream>
#include <cstdlib>
#include <string>

#include <time.h>

using namespace std;

//Creates initial deck with
// 0 to 12 locs for Spades
//13 to 25 locs for Hearts
//26 to 38 locs for Diamonds
//39 to 51 locs for Clubs
Deck::Deck() {
    Card ADDcard;
    myIndex=0;

    // Card(rank, suit s)   where
    //       rank=no. symbol of card
    //       suit=Spades/Hearts/Diam/Clubs

    for(int i=0; i<13; i++)
        {
            ADDcard= Card((i+1),Card::spades);
            myCards[i]= ADDcard;

            ADDcard= Card((i+1), Card::hearts);
            myCards[i+13]= ADDcard;

            ADDcard= Card((i+1),Card::diamonds);
            myCards[i+26]= ADDcard;

            ADDcard= Card((i+1), Card::clubs);
            myCards[i+39]= ADDcard;
        }
}

//Swaps cards but at random locations
void Deck::shuffle() {
    srand((unsigned) time(0)); //Create random value
    for(int i=0; i<SIZE; i++){
        int rando= rand() %52;
        Card cardA= myCards[rando];
        //Card cardB= myCards[i];
        myCards[rando]=myCards[i];
        myCards[i]= cardA;
    }
}

//Open the top card of deck
Card Deck::dealCard() {
    myIndex++;
    Card topcard;

    if(myIndex<52)
        {
            topcard= myCards[myIndex-1];
            return topcard;
        }
//    else{
//        return Card(-1, Card::clubs);
//        }     /* Says error */

}

//Tells me remaining size of deck
int Deck::size() const {
    return(SIZE-myIndex);
}