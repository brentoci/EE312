//
// Created by brent.o.ci on 11/2/2019.
//

#include "card.h"
#include <iostream>
#include <cstdlib>
#include <string>

#include <time.h>

using namespace std;

//Create startup of Card
Card::Card() {
    myRank=1;
    mySuit=spades;
}

//Set CARD in this file= CARD on other files
Card::Card(int rank, Card::Suit s) {
    myRank=rank;
    mySuit=s;
}

// Stamps rankString and suitString
// for complete looking card
string Card::toString() const {
    string co_card;
    co_card= rankString(myRank) + suitString(mySuit);
    return co_card;
}

// If match occurs then TRUE
bool Card::sameSuitAs(const Card &c) const {
    if(c.mySuit==mySuit)
    { return true;}
    //else {return false;}
}

int Card::getRank() const {
    return myRank;
}

//Decides if Heart, Spade, Clubs, Diamonds
string Card::suitString(Card::Suit s) const {
    string suitcard;

    if(s==clubs){
        suitcard= "c";
    }

    if(s==diamonds){
        suitcard= "d";
    }

    if(s==hearts){
        suitcard= "h";
    }

    if(s==spades){
        suitcard= "s";
    }

    return suitcard;
}

//Equates integer number to card symbols
// A, 2-10, J-K
string Card::rankString(int r) const {
    if(r==1)
    { return "A";}

    if(r==2)
    { return "2";}
    if(r==3)
    { return "3";}
    if(r==4)
    { return "4";}
    if(r==5)
    { return "5";}
    if(r==6)
    { return "6";}
    if(r==7)
    { return "7";}
    if(r==8)
    { return "8";}
    if(r==9)
    { return "9";}

    if(r==10)
    { return "10";}
    if(r==11)
    { return "J";}
    if(r==12)
    { return "Q";}
    if(r==13)
    { return "K";}
    else { return "Joker Error";} //Tells us we have a Joker


}


//These 2 make sure CARD logic works properly
bool Card::operator==(const Card &rhs) const {
    if(myRank==rhs.myRank){
        if(mySuit==rhs.mySuit){
            return true;
        }
    }
    //else{ return false;}
}

bool Card::operator!=(const Card &rhs) const {
    if(myRank!=rhs.myRank){
        if(mySuit!=rhs.mySuit){
            return true;
        }
    }
}


//ostream& operator << (ostream& out, const Card& c){
//    out << c.getRank() << " (" << c.sameSuitAs(c) << ") - " << c.toString();
//    return out;
//}


