//
// Created by brent.o.ci on 11/2/2019.
//

//#include "card.h"
#include "player.h"
#include <iostream>
#include <cstdlib>
#include <string>

#include <time.h>

using namespace std;

//vector <Card> myHand;
//vector <Card> myBook;

//Creates player who initially has no name
Player::Player() {
    myName="";
}

//Player::Player(string name) {
//
//}


//addCard at back of vector stack
void Player::addCard(Card c) {
    myHand.push_back(c);
}

//Put card-pair at back of vector stack
void Player::bookCards(Card c1, Card c2) {
    myBook.push_back(c1);
    myBook.push_back(c2);
}



//OPTIONAL
//Checks if there is a match within myHand
bool Player::checkHandForBook(Card &c1, Card &c2) {
    int i=0;
    int j=i+1;
    //Card crd1;

    while(i<myHand.size())
        {
            //crd1= myHand[i];
            //c1= myHand[i];
            while(j<myHand.size())
                {
                    //if(crd1==myHand[j])
                    if(myHand[i].getRank()==myHand[j].getRank())
                    {
                        //c1= crd1;
                        c1= myHand[i];
                        c2= myHand[j];
                        return true;
                    }
                    j++;
                    //else { j++; }
                }
            //j=0;
            i++;
            j=i+1;
        }

    return false;
}



//OPTIONAL
//Checks if cardinHand = card called
bool Player::rankInHand(Card c) const {
    int i=0;
    while(i<myHand.size())
        {
            if(myHand[i]==c)
                { return true;}
            i++;
        }

    return false;
}

//I create random location of card to check inHAND
// that is smaller than no. of cards inHAND
Card Player::chooseCardFromHand() const {
    srand((unsigned)time(0));  //Creates random value
    int choices= rand() % myHand.size();
    Card chosen= myHand[choices];
    return chosen;
}

//Checks if cardinHand = card called
bool Player::cardInHand(Card c) const {
    int i=0;
    while(i<myHand.size())
        {
            if(myHand[i].getRank()==c.getRank())
                { return true;}
            i++;
        }

    return false;
}


//Removes a card used from hand
Card Player::removeCardFromHand(Card c) {
    Card removit;
   // int refer = -7;
    int i = 0;  //i=1;

   // Must compare getRank's as myHAND[i] and c
   // can't be compared implicitly
    while (i < myHand.size()) {
        if (myHand[i].getRank() == c.getRank()) {  //
            removit = myHand[i];
            myHand.erase(myHand.begin()+ i);
            //refer = i;
            return removit;
        }
        i++;
    }
   // if (refer > (-1)) { myHand.erase(myHand.begin() + refer); }

    return removit; //return c;

}

//Displays all cards inHAND
string Player::showHand() const {
    string initial= "";
    int i=0;
    while(i<myHand.size())
        {
            initial=(initial + myHand[i].toString() + " ");
            i++;
        }

    return initial;
}

//Displays all books at myBook
string Player::showBooks() const {
    string init= "";
    int i=0;
    while(i<myBook.size())
        {
            init= (init + myBook[i].toString() + " ");
            i++;
        }

    return init;
}

//Tells you no of cards in your hand
int Player::getHandSize() const {
    int i=0;
    while(i<myHand.size())
        {
            i++;
        }
    return i;
}

//Tells you no of books won
int Player::getBookSize() const {
    int i=0;
    while(i<myBook.size())
        {
            i++;
        }
    return (i/2);
}


////OPTIONAL
////Checks if there is a match within myHand
//bool Player::checkHandForPair(Card &c1, Card &c2) {
//    int i=0;
//    int j=0;
//    Card crd1;
//
//    while(i<myHand.size())
//    {
//        crd1= myHand[i];
//        while(j<myHand.size())
//        {
//            if(crd1==myHand[j])
//            {
//                c1= crd1;
//                c2= myHand[j];
//                return true;
//            }
//            j++;
//            //else { j++; }
//        }
//
//        i++;
//    }
//
//}

////OPTIONAL
////Checks if there is match within myHand
//bool Player::sameRankInHand(Card c) const {
//
//}


